#include <iostream>
using namespace std;

int main(){
    int opcion,opcion1;
    int tima;
    double num1,num2;
    
    cout<<"********Hola********"<<endl;
    cout<<"Bienvenido a Matapp"<<endl;
    cout<<"En este programa encontraras y podras utilizar diferentes formulas matematicas y fisicas"<<endl;
    
    while(opcion!=3){
    cout<<"Elija la materia que deseas"<<endl;
    cout<<"\n menu\n1. Matematicas \n2. fisica \n3. salir."<<endl;
    cin>>opcion;
//*********************salir**********************//
    if(opcion==3){
        cout<<"saliendo del programa"<<endl;
    }
    
//*****************Matematicas********************//
    
    if(opcion==1){
        cout<<"Materia Matematicas"<<endl;
        cout<<"excelente a continuacion elije que tipo de matematica que necesitas"<<endl;
        cout<<"\n.menu \n1. matematica basica \n2. matematica media \n3. salir"<<endl;
        cin>>tima;
        
//*********************salir**********************//
        if(tima==3){
            cout<<"saliendo del programa"<<endl;
        }
        
//***************matematica basica****************//
         if(tima== 1){
             cout<<"matematica basica"<<endl;
             cout<<"elija la operacion que necesite"<<endl;
        cout<<"\nmenu \n1. suma \n2. resta \n3. multiplicacion \n4. division\n5. elevar al cuadrado \n6. elevar al cubo \n7.salir"<<endl;
        cin>>opcion1;
        
        if(opcion1==7){
            cout<<"saliendo del programa"<<endl;
        }break;
        
        if (opcion1==1){
            cout<<"escogiste suma"<<endl;
            cout<<"ingrese dos numeros\n"<<endl;
            cin>>num1>>num2;
            cout<<"la suma es:"<<num1+num2<<endl;
        }  
        if(opcion1==2) {
               cout<<"escogiste resta"<<endl;
               cout<<"ingrese dos numeros para la resta"<<endl;
               cin>>num1>>num2;
               cout<<"la resta es: "<<num1-num2<<endl;
              } 
              if(opcion1==3){
                  cout<<"escogiste multiplicar"<<endl;
                   cout<<"ingrese dos numeros para multiplicar"<<endl;
                   cin>>num1>>num2;
                   cout<<"la multiplicacion es: "<<num1*num2<<endl;
                  } 
                  if(opcion1==4){
                      cout<<"escogiste division"<<endl;
                       cout<<"ingrese dos numeros para dividir"<<endl;
                       cin>>num1>>num2;
                       cout<<"la division es: "<<num1/num2<<endl;
                  } 
                  if(opcion1==5){
                      cout<<"escogiste elevar al cuadrado"<<endl;
                      cout<<"ingrese el numero a elevar"<<endl;
                      cin>>num1;
                      cout<<"la elevacion es: "<<num1*num1<<endl;
                  }
                  if(opcion1==6){
                      cout<<"escogiste elevar al cubo"<<endl;
                      cout<<"ingrese el numero"<<endl;
                      cin>>num1;
                      cout<<"la elevacion es:"<<num1*num1*num1<<endl;
                  }
         }
//****************matematica media*****************//
             if(tima== 2){
             cout<<"matematica media"<<endl;
             cout<<"escoge la operacion que necesites"<<endl;
             
             cout<<"\n. menu \n1.hallar areas de figuras \n2. salir"<<endl;
             cin>>opcion1;
             
             if(opcion1== 2){
                 cout<<"saliendo del programa"<<endl;
                 break;
//*****************hallar areas*********************//
             }if(opcion1==1){
                 
             cout<<"\n.menu \n1. hallar area cuadrado \n2. hallar area triangulo"<<endl;
             cin>>opcion1;
//****************hallar area cuadrado**************//
                 if(opcion1==1){
                 cout<<"escogiste hallar area de cuadrado"<<endl;
                 cout<<"ingrese la medida de dos lados\n"<<endl;
                 cin>>num1>>num2;
                 cout<<"el area del cuadrado es: "<<num1*num2<<endl;
            }
//*************hallar area de triangulo**************//
            if(opcion1==2){
                cout<<"escogiste hallar area de triangulo"<<endl;
                cout<<"ingrese la altura"<<endl;
                cin>>num1;
                cout<<"ingrese la base"<<endl;
                cin>>num2;
                cout<<"el area del triangulo es: "<<num1*num2/2<<endl;
            } 
            }
    }
}
//*****************fisica********************//

if(opcion==2){
    cout<<"escogiste la materia fisica"<<endl;
    cout<<"\n menu \n1.hallar velocidad \n2. hallar tiempo \n3. hallar distancia \n4. salir \n"<<endl;
    cin>>opcion1;
    
    if(opcion1==1){
        cout<<"elejiste hallar velocidad"<<endl;
        cout<<"ingrese la distancia en metros: "<<endl;
        cin>>num1;
        cout<<"ingrese el tiempo en segundos: "<<endl;
        cin>>num2;
        cout<<"la velocidad es: "<<num1/num2<<"m/s"<<endl;
    }
    if (opcion1==2){
        cout<<"elejiste hallar tiempo"<<endl;
        cout<<"ingrese la distancia en metros:"<<endl;
        cin>>num1;
        cout<<"ingrese la velocidad en m/s:"<<endl;
        cin>>num2;
        cout<<"el tiempo es: "<<num1/num2<<"s"<<endl;
    }
    if(opcion1==3){
        cout<<"elejiste hallar distancia"<<endl;
        cout<<"ingrese la velocidad en m/s: "<<endl;
        cin>>num1;
        cout<<"ingrese el tiempo en s: "<<endl;
        cin>>num2;
        cout<<"la distancia es: "<<num1*num2<<"m"<<endl;
    }
    if(opcion1==4){
        cout<<"saliendo del programa"<<endl;
    }
}
}
return 0;
}
